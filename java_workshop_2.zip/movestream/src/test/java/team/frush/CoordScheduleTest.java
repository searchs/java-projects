package team.frush;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;

import static org.junit.Assert.*;

public class CoordScheduleTest {

    CoordSchedule coordSchedule;

//    @Before
//    public void setUp() throws Exception {
//        coordSchedule = new CoordSchedule();
//    }
//
//    @After
//    public void tearDown() throws Exception {
//
//    }

    @Test
    @DisplayName("Frequency must be less than 1440")
    public void testFrequency() {
        coordSchedule = new CoordSchedule();
        Assertions.assertTrue(coordSchedule.getFrequency() < 1440);

    }
}