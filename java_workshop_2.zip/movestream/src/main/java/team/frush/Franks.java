package team.frush;

public class Franks {

    public static void main(String[] args) {
        System.out.println("Running Franks Box of Oozie!");

    }

}
