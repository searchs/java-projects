package team.frush;

public class CoordSchedule {


    private String startingTimestamp;
    private String endingTimestamp;
    private int frequency;

    public int getFrequency() {
        return 0;
    }
}
