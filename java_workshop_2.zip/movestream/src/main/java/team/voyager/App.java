package team.voyager;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.List.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Hello world!
 */
public class App {
    public static void main(String[] args) {
        System.out.println("Getting Java Streams flowing ....");
        Stream<Object> objStream = Stream.of(new Object(), new Object(), new Object());
        System.out.println(objStream.findAny());
        System.out.println("Now Stream strings of names with map, filters et al");

//        LIST
        List<String> strList = Arrays.asList("Jack", "Jade", "James", "Dare", "Jare", "Boss", "Momsy", "Subola", "Spencer", "Kreate");
        Stream<String> strStream = strList.stream();
        List<String> result = strStream.
                filter(name -> !name.startsWith("J"))
                .map(name -> name.toLowerCase())
                .collect(Collectors.toList());
        System.out.println(result);


        System.out.println("Using ArrayList: ....");
        String[] strArray = new String[]{"Volvo", "BMW", "Benz", "Jaguar", "Tesla", "Toyota", "Peogeot", "xClass"};
        Stream<String> carStream = Arrays.stream(strArray);
        List<String> road = carStream.filter(car -> car.contains("o")).collect(Collectors.toList());
        road.forEach(c -> System.out.println(c));

//        Nullable
//        Stream<Object> nullableStream = Stream.ofNullable(new Object());
        Stream<Integer> streamInt = Stream.iterate(0, (i) -> {
            return i + 1;
        }).limit(6);
        List<Integer> resInt = streamInt.map(
                n -> n * n).collect(Collectors.toList());
        System.out.println(resInt);

//        Stream - Temporary Buffer
        Stream.Builder<String> streamBuilder = Stream.builder();
        for (int i = 0; i < 10; i++) {
            streamBuilder.accept("String " + i);
        }

        streamBuilder.add("Done");
        List<String> streamList = streamBuilder.build().collect(Collectors.toList());
        System.out.println(streamList);

    }

}
