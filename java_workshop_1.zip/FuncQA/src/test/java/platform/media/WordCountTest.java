package platform.media;

import com.reachteam.iot.DailyGoals;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import static org.junit.jupiter.api.Assertions.*;

class WordCountTest {

    WordCount wordCount;

    @ParameterizedTest
    @CsvSource({
            "'A man, a plan, a canal. Panama', 7",
            "'Able was I ere I saw Elba', 7",
            "'Boy meets',     2",
            "'9999',   1",
            ",  0",
            "'',  0",
            "'   ',0",
            "'Strawberry and chocolate is flowing, down the river',8",
            "'Charle\'s Chocolate Factory movie', 4",
            "' A cat in the hat with spaces ', 7"

    })
    public void testGetWordCount(String textCheck, int expected) {
        wordCount = new WordCount();
        // Using a lambda will lazily evaluate the expression
        Assertions.assertTrue(
                wordCount.getWordCount(textCheck) == expected,
                () -> "With " + textCheck +
                        " steps, getWordCount() should return " +
                        expected);
    }

}