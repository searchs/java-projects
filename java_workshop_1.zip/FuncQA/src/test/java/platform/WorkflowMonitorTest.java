package platform;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class WorkflowMonitorTest {
    private EmailNotifier emailNotifier;
    private WorkFlowClient workflowClient;
    private WorkflowMonitor workflowMonitor;

    @BeforeAll
    public void setUpMocks() {
        emailNotifier = mock(EmailNotifier.class);
        workflowClient = mock(WorkFlowClient.class);
        workflowMonitor = new WorkflowMonitor(emailNotifier, workflowClient);
    }


    @Test
    public void testSuccess() {
        String id = "WORKFLOW-1";
        WorkFlowStatus workFlowStatus = new WorkFlowStatus(id, WorkFlowStatus.OK);
        when(workflowClient.getStatus(id)).thenReturn(workFlowStatus);
        workflowMonitor.checkStatus(id);
        verify(emailNotifier, times(0)).sendFailureEmail(workFlowStatus);
    }

    @Test
    public void testFailure(){
        String id = "WORKFLOW-1";
        WorkFlowStatus workFlowStatus = new WorkFlowStatus(id, WorkFlowStatus.ERROR);
        when(workflowClient.getStatus(anyString())).thenReturn(workFlowStatus);
        workflowMonitor.checkStatus(id);
        verify(emailNotifier).sendFailureEmail(workFlowStatus);


    }



}