package com.reachteam.nlytics;

//import org.junit.After;
//import org.junit.Before;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;

class CoordinatorScheduleTest {
    CoordinatorSchedule coordinatorSchedule;

//    @Before
//    public void setUp() throws Exception {
////        coordinatorSchedule = new CoordinatorSchedule("","", 5);
//        System.out.println("Before tests begin");
//    }


    //    @After
//    public void tearDown() throws Exception {
//        if (coordinatorSchedule != null) {
//            coordinatorSchedule = null;
//        }
//    }
    @Test
    @DisplayName("Frequency must be less than 1440")
    public void testFrequencyUpperLimit() {
//        Assertion
        coordinatorSchedule = new CoordinatorSchedule(
                "2020-12-15T15:32Z",
                "2020-12-30T05:15Z",
                60);
        assertTrue(coordinatorSchedule.getFrequency() < CoordinatorSchedule.MAX_FREQUENCY);
        assertTrue(coordinatorSchedule.getFrequency() >= CoordinatorSchedule.MIN_FREQUENCY);

    }


    @Test
    @DisplayName("Frequency must be greater than 5")
    public void testFrequencyLowerLimit() {
//        Assertion
        coordinatorSchedule = new CoordinatorSchedule(
                "2020-12-15T15:32Z",
                "2020-12-30T05:15Z",
                5);
        assertTrue(coordinatorSchedule.getFrequency() >= CoordinatorSchedule.MIN_FREQUENCY);
        assertTrue(coordinatorSchedule.getFrequency() < CoordinatorSchedule.MAX_FREQUENCY);

    }

    @Test
    @DisplayName("Timestamp will be null if not formatted correctly")
    void testStartingTimestamps() {
        coordinatorSchedule = new CoordinatorSchedule(
                "2020/12/15T15:32Z",
                "2020-12-15T15:35Z",
                60
        );
        Date starting = coordinatorSchedule.getStartingTimestampAsDate();
// Timestamp is not formatted properly.
        Assertions.assertNull(starting);
    }



    @Test
    @DisplayName("Ending timestamp must be after starting")
    void testTimestamps() {
         coordinatorSchedule = new CoordinatorSchedule(
                "2020-12-15T15:32Z",
                "2020-12-15T15:35Z",
                60
        );
        Date starting = coordinatorSchedule.getStartingTimestampAsDate();
        Assertions.assertNotNull(starting);
        Date ending = coordinatorSchedule.getEndingTimestampAsDate();
        Assertions.assertNotNull(ending);
        Assertions.assertTrue(ending.after(starting));
    }


//    @ParameterizedTest
//    @ValueSource(ints = { 10000, 11000 })
//    public void testMetStepGoal(int steps) {
//        DailyGoal dailyGoal = new DailyGoal(DAILY_GOAL);
//        Assertions.assertTrue(dailyGoal.hasMetGoal(steps));
//    }

//    @ParameterizedTest
//    @CsvSource({
//            "10,     false",
//            "9999,   false",
//            "10000,  true",
//            "20000,  true"
//    })
//    public void testHasMetStepGoal(int steps, boolean expected) {
//        // ...
//    }

//Passing NULLS in test data
//    @CsvSource({
//            "'A man, a plan, a canal. Panama',  7",
//            "'Able was I ere I saw Elba',  7",
//            ", 0", //NULL value
//            "'', 0" //empty string
//    })

}