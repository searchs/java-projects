package com.reachteam.iot;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;

import static org.junit.jupiter.api.Assertions.*;

//@TestInstance(TestInstance.Lifecycle.PER_CLASS) //one instance for all tests!!!!!?
class DailyGoalsTest {


    DailyGoals dailyGoals;
    public static final int DAILY_GOAL = 10000;


//    public DailyGoalsTest(DailyGoals dailyGoals) {
//        this.dailyGoals = dailyGoals;
//    }

    @ParameterizedTest
    @ValueSource(ints = {10000, 11000, 19000})
//    @CsvSource({
//            "10,     false",
//            "9999,   false",
//            "10000,  true",
//            "20000,  true"
//    })
    public void testHasMetStepGoal(int steps) {
        dailyGoals = new DailyGoals(DAILY_GOAL);
        Assertions.assertTrue(dailyGoals.hasMetGoal(steps));
    }

    @ParameterizedTest
    @ValueSource(ints = {10, 9999})
    public void testNotMetStepGoal(int steps) {
        dailyGoals = new DailyGoals(DAILY_GOAL);
        Assertions.assertFalse(dailyGoals.hasMetGoal(steps));
    }


    @ParameterizedTest
    @CsvSource({
            "10,     false",
            "9999,   false",
            "10000,  true",
            "20000,  true"
    })
    public void testHasMetStepGoal(int steps, boolean expected) {
        dailyGoals = new DailyGoals(DAILY_GOAL);
        // Using a lambda will lazily evaluate the expression
        Assertions.assertTrue(
                dailyGoals.hasMetGoal(steps) == expected,
                () -> "With " + steps +
                        " steps, hasMetGoal() should return " +
                        expected);
    }


    @Disabled("Until platform team fixes issue 5578")
    @Test
    public void testThatShouldNotFail() {
        System.out.println("Should not run this test.  If you see this, BAD!");
    }

}