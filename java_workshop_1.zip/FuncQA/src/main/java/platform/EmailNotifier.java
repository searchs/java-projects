package platform;

public class EmailNotifier {

    public void sendFailureEmail(WorkFlowStatus workFlowStatus) {
        //code here - leave for onw to use Mockito
    }




}
