package platform.fp;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Shopping {

    public static void main(String[] args) {

    }


    public static final class ShoppingCart {
        private final List<ShoppingItem> shoppingItemList; //= new ArrayList<>();

        public ShoppingCart(List<ShoppingItem> list) {
            shoppingItemList = Collections.unmodifiableList(list);
        }

        public void addITem(ShoppingItem item) {
            shoppingItemList.add(item);
        }
    }


    private static final class ShoppingItem {
        private final String name;
        private final int price;

        public ShoppingItem(String name, int price) {
            this.name = name;
            this.price = price;
        }
    }

}
