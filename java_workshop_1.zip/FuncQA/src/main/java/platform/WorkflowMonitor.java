package platform;

public class WorkflowMonitor {
    private EmailNotifier emailNotifier;
    private WorkFlowClient workFlowClient;

    public WorkflowMonitor(EmailNotifier emailNotifier, WorkFlowClient workFlowClient) {
        this.emailNotifier = emailNotifier;
        this.workFlowClient = workFlowClient;
    }

    public void checkStatus(String id) {
        WorkFlowStatus workFlowStatus = workFlowClient.getStatus(id);
        if (!workFlowStatus.isOK()) {
            emailNotifier.sendFailureEmail(workFlowStatus);
        }
    }


}
