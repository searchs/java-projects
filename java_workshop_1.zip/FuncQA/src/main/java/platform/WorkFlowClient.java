package platform;

public class WorkFlowClient {
    public WorkFlowStatus getStatus(String id){
        return new WorkFlowStatus(id, WorkFlowStatus.OK);
    }


}
