package platform.media;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class WordCount {

    public int getWordCount(String textCheck) {
        if (textCheck != null) {
            if (textCheck.isEmpty() || textCheck.isBlank()) {
                return 0;
            }
            return Arrays.asList(textCheck.trim().split("\\s+")).size();
        }
        return 0;
    }

    public static void main(String[] args) {
        System.out.println("Ready to run WordCount");
        WordCount wordCount = new WordCount();
        int counted = wordCount.getWordCount("Dancing in the attic is the new normal and the eventual cause " +
                "of rising house prices in Hillingdon");
        System.out.println(counted);
    }
}
