package com.reachteam.iot;

public class DailyGoals {

//    public static final int DAILY_GOAL = 10000;
    int dailyGoal = 10000;

    public DailyGoals(int dailyGoal) {
        this.dailyGoal = dailyGoal;
    }

    public boolean hasMetGoal(int steps) {
        if (steps >= dailyGoal) {
            return true;
        }
        return false;
    }



}
